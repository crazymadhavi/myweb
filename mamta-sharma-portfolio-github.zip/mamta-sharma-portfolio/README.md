# Mamta Sharma — Sales Executive Portfolio

Single-page responsive portfolio website built with HTML and CSS.

## Files
- `index.html` — complete portfolio website (HTML + embedded CSS)

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save. GitHub will publish the portfolio.
